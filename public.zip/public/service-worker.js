/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "404.html",
    "revision": "c9f4f80668b3777c4904c53aa5124c99"
  },
  {
    "url": "assets/css/0.styles.7674e60c.css",
    "revision": "5b7531c3ab7f8c7fba6195b775341101"
  },
  {
    "url": "assets/img/bg.a2d1cf1a.svg",
    "revision": "a2d1cf1ad2becdd79823541dae101fcd"
  },
  {
    "url": "assets/js/1.e23ef5ac.js",
    "revision": "ad0716d69e4d80a539f30fcde0edf0ef"
  },
  {
    "url": "assets/js/10.0c9d1282.js",
    "revision": "bb54878fd7bfcbbc83ef452c4ac818f0"
  },
  {
    "url": "assets/js/11.e3aa095f.js",
    "revision": "8d31395d7ee3475b58584a0a08b61501"
  },
  {
    "url": "assets/js/12.a841472f.js",
    "revision": "4d9596d6bbf33351cd9df84ac7793a77"
  },
  {
    "url": "assets/js/13.a9cbe8f2.js",
    "revision": "7737b406eddd806c3d53addd0e7eb759"
  },
  {
    "url": "assets/js/14.735ad7e2.js",
    "revision": "651b5f9abf3acf345aac40f0100a16e1"
  },
  {
    "url": "assets/js/15.f237e9f5.js",
    "revision": "2cb2d2df208abcefd1db9ed6f54167c7"
  },
  {
    "url": "assets/js/16.374bf3c8.js",
    "revision": "df99b010ebcdad6668e9d835fd186299"
  },
  {
    "url": "assets/js/17.a78a3f52.js",
    "revision": "ce65eb2fc95023cd852b4389e5b64732"
  },
  {
    "url": "assets/js/18.1ee197dc.js",
    "revision": "dcb690b1eb2264496849f0d9c5e726e2"
  },
  {
    "url": "assets/js/19.235b8ad3.js",
    "revision": "1c753b74b7ff129ab638db3733b2238e"
  },
  {
    "url": "assets/js/2.89c44d46.js",
    "revision": "4f064568f0567bec6b28f323734fa24f"
  },
  {
    "url": "assets/js/20.505a1df4.js",
    "revision": "9d0730278ad03a618037fba6c8b83f89"
  },
  {
    "url": "assets/js/21.40d8392a.js",
    "revision": "5da96ef6e3149f90db24f582b2dc5a88"
  },
  {
    "url": "assets/js/22.85934f99.js",
    "revision": "37ac0ca1662cfd52f13a38341d1994f7"
  },
  {
    "url": "assets/js/23.5670dc7d.js",
    "revision": "a9169124b45e1082c5b8f50436816503"
  },
  {
    "url": "assets/js/24.79ddaadd.js",
    "revision": "aaeafc19d720be1dc2116f51e475b0c6"
  },
  {
    "url": "assets/js/25.8513a2a8.js",
    "revision": "6ab256ecfa0f77f9755e2548ba3974bb"
  },
  {
    "url": "assets/js/26.67932ed8.js",
    "revision": "4aa4d43b6bdbc2f36c9c747d8a510626"
  },
  {
    "url": "assets/js/27.8a3194f3.js",
    "revision": "1148420c4d60b7e9734b5dc273cfa78a"
  },
  {
    "url": "assets/js/28.f1ad883d.js",
    "revision": "d08fbdc98bcde2fba973abf05437bcac"
  },
  {
    "url": "assets/js/29.281b3c73.js",
    "revision": "b570d0d6c3d8d21207f1c5f794e386eb"
  },
  {
    "url": "assets/js/30.7d73f3da.js",
    "revision": "a6822567ab5082339a202ed9778c6f04"
  },
  {
    "url": "assets/js/31.57e8db04.js",
    "revision": "cdcef6b3ac96d56fc777cf2952ab1b9d"
  },
  {
    "url": "assets/js/32.86de2248.js",
    "revision": "ea507d0a132971e1c75cdc20ab9bf145"
  },
  {
    "url": "assets/js/33.79974a07.js",
    "revision": "136abd6a261260d189d4c5d54c7ba849"
  },
  {
    "url": "assets/js/4.f304ff9b.js",
    "revision": "686401d3acbdf4887ebd19eac013f810"
  },
  {
    "url": "assets/js/5.81616cf1.js",
    "revision": "bc12e662aa5530e38265d2a068247541"
  },
  {
    "url": "assets/js/6.06226572.js",
    "revision": "0772e79937d962f0963c0bc4adc3c893"
  },
  {
    "url": "assets/js/7.3616d0ea.js",
    "revision": "9b80d63e57f0d1536bba1c1665dc0baf"
  },
  {
    "url": "assets/js/8.3fcd1e91.js",
    "revision": "c247f95ca90dfbe05b9033433a560612"
  },
  {
    "url": "assets/js/9.c5298c85.js",
    "revision": "d33638e820928807fb29f221ff77e476"
  },
  {
    "url": "assets/js/app.cb1be4e4.js",
    "revision": "2e2e825deaa90adb94c38ce8505c0015"
  },
  {
    "url": "avatar.png",
    "revision": "9e0cf1b286c6d2d6c4ed4a142982c7dc"
  },
  {
    "url": "blogs/frontEnd/2021/Angular1.html",
    "revision": "4884fe3fe9dd543beab8f43046099e2a"
  },
  {
    "url": "blogs/frontEnd/2021/Angular2.html",
    "revision": "cf230c71649bcfde9d680e76d1bb1e5f"
  },
  {
    "url": "blogs/frontEnd/2021/Angular3.html",
    "revision": "d070f143fcaa62d3d8d0dc76fa58b764"
  },
  {
    "url": "blogs/frontEnd/2021/array_opts.html",
    "revision": "0ee5260412846fb553621c3a1f3317dc"
  },
  {
    "url": "blogs/frontEnd/2021/async_await.html",
    "revision": "aba84a66628df24444470c837b205686"
  },
  {
    "url": "blogs/frontEnd/2021/element_table.html",
    "revision": "230fc84591f6fdd9f2b773efd58e7fb2"
  },
  {
    "url": "blogs/frontEnd/2021/git_ssh.html",
    "revision": "f9001d2f5ab1394ead80ba61224e9847"
  },
  {
    "url": "blogs/frontEnd/2021/handwriten_senior.html",
    "revision": "468627eaabb730b98ee86fa296b49431"
  },
  {
    "url": "blogs/frontEnd/2021/JS_senior.html",
    "revision": "8438a9e2061d849f1356b09f41596046"
  },
  {
    "url": "blogs/frontEnd/2021/js_sort.html",
    "revision": "77c510ad7fba626d8290176ca6e61490"
  },
  {
    "url": "blogs/frontEnd/2021/npm_notes.html",
    "revision": "67cae701edfdab9dff41d63e7116d3d1"
  },
  {
    "url": "blogs/frontEnd/2021/promise.html",
    "revision": "fc806ba871fd4ecb43f2927ae5af310a"
  },
  {
    "url": "blogs/frontEnd/2021/terminal.html",
    "revision": "4b6f9b5791611ac8e95640ddbdf80a37"
  },
  {
    "url": "blogs/frontEnd/2021/tsstudy.html",
    "revision": "d15450e090009b80328f46020a43d956"
  },
  {
    "url": "blogs/frontEnd/2021/vnote.html",
    "revision": "ea199f7f8805d44de5ccfea118a73048"
  },
  {
    "url": "blogs/frontEnd/2021/VuepressAutoCommit.html",
    "revision": "9ff5cd202b8ba7de2353a665955744da"
  },
  {
    "url": "blogs/frontEnd/2022/echarts.html",
    "revision": "50008d9ce89d9e1a8c8774688f150da9"
  },
  {
    "url": "blogs/frontEnd/2022/MongoDB.html",
    "revision": "83ed672c6fd036a54dcc231c288a6d85"
  },
  {
    "url": "blogs/frontEnd/2022/Nodejs.html",
    "revision": "ec40f4e2991d5171781690e7ff9e637b"
  },
  {
    "url": "blogs/frontEnd/2022/react01.html",
    "revision": "4ffaa191ea9c5acf11ccb0b41e8b40e5"
  },
  {
    "url": "categories/index.html",
    "revision": "19bfea61648efa35de86f48f41b061bc"
  },
  {
    "url": "categories/前端基础/index.html",
    "revision": "de08755d0b110a3ff5f4f9947e03e832"
  },
  {
    "url": "categories/前端框架/index.html",
    "revision": "fb234f9f4b2b4a78c75644f74bea450d"
  },
  {
    "url": "categories/后端学习/index.html",
    "revision": "614cac9d6991b82d827b76437de78fa3"
  },
  {
    "url": "categories/踩坑积累/index.html",
    "revision": "be489ee6fb1f0aac4c85aa9425d941a9"
  },
  {
    "url": "css/znote.css",
    "revision": "4d63fe30b28a28bc914ee3df925355fc"
  },
  {
    "url": "fonts/iconfont.css",
    "revision": "36d5d3fa4b12e4eee628d08c9e5d8a85"
  },
  {
    "url": "fonts/iconfont.js",
    "revision": "292dfb4f28a4f76de893bc2812d9a137"
  },
  {
    "url": "fonts/iconfont.ttf",
    "revision": "dc2cc1f9a42325b98ee8e446dee5b5e2"
  },
  {
    "url": "fonts/iconfont.woff",
    "revision": "f03c4a59a9dfac313eb4a0788443bda1"
  },
  {
    "url": "fonts/iconfont.woff2",
    "revision": "35f2db7ef28e1ada5cd9cbd1d7609ffb"
  },
  {
    "url": "head.jpg",
    "revision": "8eeef30c4646f3ac50f483029cef9f5f"
  },
  {
    "url": "hero.png",
    "revision": "5367b9349d4e048235eeed50d9ef36df"
  },
  {
    "url": "index.html",
    "revision": "acdcffb869a01b2bc246090759e08fac"
  },
  {
    "url": "js/myjs.js",
    "revision": "1940fed841c891f031a4e8e9ee4616bd"
  },
  {
    "url": "logo.png",
    "revision": "aeea480d9c271fc3a8a47e0b82641bec"
  },
  {
    "url": "tag/Angular/index.html",
    "revision": "c299c28ac229ddb899f115d1b80a8f76"
  },
  {
    "url": "tag/Echarts/index.html",
    "revision": "c6e442a9675ff94229407d7d5cda2e98"
  },
  {
    "url": "tag/ElementUI/index.html",
    "revision": "46ca7d0d4af16e1ea74bf0c8e53b5345"
  },
  {
    "url": "tag/Git/index.html",
    "revision": "e006e6803a816db9b09958e43ce77f49"
  },
  {
    "url": "tag/index.html",
    "revision": "70b654e3cf8323d8dd4991add327c21e"
  },
  {
    "url": "tag/JavaScript/index.html",
    "revision": "3cce9b105b357387fec24078005d259f"
  },
  {
    "url": "tag/MongoDB/index.html",
    "revision": "dd2b33c9ebebecea294bcdbf68d9776d"
  },
  {
    "url": "tag/Node/index.html",
    "revision": "760b5b1bd4197ebb631441ae5620d215"
  },
  {
    "url": "tag/NPM/index.html",
    "revision": "08ca49f0e60f8aee8fb6e8508720804e"
  },
  {
    "url": "tag/Promise/index.html",
    "revision": "d0fd1acb2c669bd037e6a503e0c5ec3e"
  },
  {
    "url": "tag/React/index.html",
    "revision": "def6b320e20a41c766c9934ecf4339cf"
  },
  {
    "url": "tag/Terminal/index.html",
    "revision": "acebefcda22fb982c162d56552ad731f"
  },
  {
    "url": "tag/TypeScript/index.html",
    "revision": "572359ddd08c559758bf24c98dd7266e"
  },
  {
    "url": "tag/VuePress/index.html",
    "revision": "efa1cf4d05612c21df2240162563fb4e"
  },
  {
    "url": "tag/排序算法/index.html",
    "revision": "cb6676f86ebf9a2e0779c14cc0fdefac"
  },
  {
    "url": "tag/数组处理/index.html",
    "revision": "755f8c1e14869d60a985a471f134dd20"
  },
  {
    "url": "timeline/index.html",
    "revision": "035f9efd223ba5dc89c2084ca45c2f9f"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
addEventListener('message', event => {
  const replyPort = event.ports[0]
  const message = event.data
  if (replyPort && message && message.type === 'skip-waiting') {
    event.waitUntil(
      self.skipWaiting().then(
        () => replyPort.postMessage({ error: null }),
        error => replyPort.postMessage({ error })
      )
    )
  }
})
